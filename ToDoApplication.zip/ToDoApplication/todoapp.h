#ifndef TODOAPP_H
#define TODOAPP_H

#include <QMainWindow>
#include<QListWidgetItem>


QT_BEGIN_NAMESPACE
namespace Ui { class ToDoApp; }
QT_END_NAMESPACE

class ToDoApp : public QMainWindow
{
    Q_OBJECT

public:
    ToDoApp(QWidget *parent = nullptr);
    ~ToDoApp();

private slots:



    void on_action_View_pending_tasks_toggled(bool arg1);

    void on_action_View_finished_tasks_toggled(bool arg1);

    void on_action_About_Qt_triggered();

    void on_action_Exit_triggered();

    void on_action_Save_triggered();
    void on_action_Open_triggered();

    void on_action_View_today_tasks_toggled(bool arg1);

    void on_action_About_triggered();

    void on_action_New_triggered();

    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);

    void on_pendingT_itemDoubleClicked(QListWidgetItem *item);

    void on_finishedT_itemDoubleClicked(QListWidgetItem *item);


    void on_action_Add_task_triggered();

    void on_action_Remove_task_triggered();

protected:
    void saveTasks(QString);
    void loadTasks(QString);
//    virtual void dropEvent(QDropEvent *e)override;
//    virtual void dragEnterEvent(QDragEnterEvent *e)override;
//    virtual void dragLeaveEvent(QDragLeaveEvent *e)override;
//    virtual void dragMoveEvent(QDragMoveEvent *e)override;

private:
    Ui::ToDoApp *ui;
    QString currentFile;


};
#endif // TODOAPP_H
