#include "addtaskdialog.h"
#include "ui_addtaskdialog.h"

addTaskDialog::addTaskDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addTaskDialog)
{
    ui->setupUi(this);
    QDate date = QDate::currentDate();
    ui->dateEdit->setMinimumDate(date);
    ui->dateEdit->setDate(date);
}

addTaskDialog::~addTaskDialog()
{
    delete ui;
}
QString addTaskDialog::getTask(){
    return ui->lineEdit->text()+ " Due: "+ui->dateEdit->text() + " Tag: " +ui->comboBox->currentText();
}
QDate addTaskDialog::getDate(){
    return ui->dateEdit->date();
}
bool addTaskDialog::get_if_is_a_FinishedTask(){
    return ui->checkBox->isChecked();
}
QString addTaskDialog::getTag(){
    return ui->comboBox->currentText();
}
void addTaskDialog::setDescription(QString description){
    ui->lineEdit->setText(description)  ;

}
void addTaskDialog::setDate(QString date){
    QStringList datelist= date.split("/");
    QDate d(datelist[2].toInt(),datelist[1].toInt(),datelist[0].toInt());
    ui->dateEdit->setDate(d);
}
void addTaskDialog::setTag(QString tag){
    ui->comboBox->setItemText(0,tag)  ;
}
void addTaskDialog::setFinished(bool finished){
    ui->checkBox->setChecked(finished) ;
}
