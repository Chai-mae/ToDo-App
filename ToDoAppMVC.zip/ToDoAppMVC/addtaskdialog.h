#ifndef ADDTASKDIALOG_H
#define ADDTASKDIALOG_H

#include <QDialog>

namespace Ui {
class addTaskDialog;
}

class addTaskDialog : public QDialog
{
    Q_OBJECT

public:
    explicit addTaskDialog(QWidget *parent = nullptr);
    ~addTaskDialog();
    QString getTask();
    QDate getDate();
    QString getTag();
    bool get_if_is_a_FinishedTask();
    void setDescription(QString);
    void setDate(QString);
    void setTag(QString);
    void setFinished(bool);

private:
    Ui::addTaskDialog *ui;


};

#endif // ADDTASKDIALOG_H
