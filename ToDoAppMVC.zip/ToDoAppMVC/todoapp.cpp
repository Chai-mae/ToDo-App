#include "todoapp.h"
#include "ui_todoapp.h"
#include "addtaskdialog.h"
#include<QDate>
#include<QMessageBox>
#include<QFile>
#include<QTextStream>
#include<QFileDialog>
#include<QVector>
#include<QDebug>


ToDoApp::ToDoApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ToDoApp)
{
    ui->setupUi(this);
    todayModel = new QStringListModel(this);
    pendingModel = new QStringListModel(this);
    finishedModel = new QStringListModel(this);

    ui->pendingL->setVisible(false);
    ui->finishedL->setVisible(false);

    ui->todayL->setDragEnabled(true);
    ui->pendingL->setDragEnabled(true);


    ui->todayL->setAcceptDrops(true);
    ui->pendingL->setAcceptDrops(true);
    ui->finishedL->setAcceptDrops(true);

    ui->todayL->setDropIndicatorShown(true);
    ui->pendingL->setDropIndicatorShown(true);
    ui->finishedL->setDropIndicatorShown(true);

    ui->todayL->setDefaultDropAction(Qt::MoveAction);
    ui->pendingL->setDefaultDropAction(Qt::MoveAction);
    ui->finishedL->setDefaultDropAction(Qt::MoveAction);



    QFile file("file.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QString path = file.readLine();
        loadTasks(path);
    }





    setWindowTitle("To do app");
}

ToDoApp::~ToDoApp()
{
    delete ui;
    delete todayModel;
    delete pendingModel;
    delete finishedModel;
}


void ToDoApp::on_action_Add_triggered()
{
    addTaskDialog dialog;
    auto reply=dialog.exec();
    if (reply==addTaskDialog::Accepted)
    {
        if (dialog.get_if_is_a_FinishedTask())
        {

         finishedList.push_back(dialog.getTask());

           finishedModel->setStringList(finishedList);
           ui->finishedL->setModel(finishedModel);


        }
     else if (QDate::currentDate() == dialog.getDate())
       {
            todayList.push_back(dialog.getTask());

              todayModel->setStringList(todayList);
              ui->todayL->setModel(todayModel);
        }
     else{
            pendingList.push_back(dialog.getTask());

              pendingModel->setStringList(pendingList);
              ui->pendingL->setModel(pendingModel);

}

    }



}

void ToDoApp::on_action_View_pending_tasks_toggled(bool arg1)
{
    if(arg1)
        ui->pendingL->setVisible(true);
    else
        ui->pendingL->setVisible(false);
}


void ToDoApp::on_action_View_finished_tasks_toggled(bool arg1)
{
    if(arg1)
        ui->finishedL->setVisible(true);
    else
        ui->finishedL->setVisible(false);
}


void ToDoApp::on_action_About_Qt_triggered()
{
      QMessageBox::aboutQt(this, "About Me");
}


void ToDoApp::on_action_Exit_triggered()
{
    QFile file("File.txt");
      if (file.open(QIODevice::ReadWrite | QIODevice::Text)){
           QTextStream stream(&file);
           stream<< currentFile;
           file.close();
      }

    this->close();
}

void ToDoApp::saveTasks(QString filename){
    QFile file(filename);
       if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {

           QTextStream stream(&file);
           stream<< "List of Today's tasks :" << Qt::endl;
           for (int i = 0; i < todayList.length(); i++) {

               stream << todayList[i] << Qt::endl;
           }
           stream<< "List of pending tasks :" << Qt::endl;
           for (int i = 0; i < pendingList.length(); i++) {

               stream << pendingList[i] << Qt::endl;
           }
           stream<< "List of finished tasks :" << Qt::endl;
           for (int i = 0; i <finishedList.length(); i++) {

               stream << finishedList[i] << Qt::endl;
           }


           file.close();
       }

}
void ToDoApp::on_action_Save_triggered()
{
    if(currentFile == "")
    {

        QFileDialog d;
        auto filename = d.getSaveFileName();
        currentFile = filename;
        setWindowTitle(currentFile);

    }

    saveTasks(currentFile);

}
void ToDoApp::loadTasks(QString filename){

    QFile file(filename);
          if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {

              QTextStream in(&file);
              QVector<QString> tasks;
              while(!in.atEnd()) {
                  QString line = in.readLine();
                  tasks.append(line);

              }

             int t= tasks.indexOf("List of pending tasks :");
             int p= tasks.indexOf( "List of finished tasks :");
             for (auto i=1; i<t ; i++ ){

                 todayList.append(tasks[i]);

             }

             for (auto i=t+1; i<p ; i++ )
                {

                 pendingList.append(tasks[i]);

             }
             for (auto i=p+1; i<tasks.size() ; i++ )
             {

                 finishedList.append(tasks[i]);

             }


              file.close();
          }
          todayModel->setStringList(todayList);
          ui->todayL->setModel(todayModel);
          pendingModel->setStringList(pendingList);
          ui->pendingL->setModel(pendingModel);
          finishedModel->setStringList(finishedList);
          ui->finishedL->setModel(finishedModel);
}


void ToDoApp::on_action_Open_triggered()
{
    QFileDialog d;
    auto filename = d.getOpenFileName();
    currentFile =filename;
   setWindowTitle(currentFile);

       loadTasks(currentFile);


}


void ToDoApp::on_action_View_today_tasks_toggled(bool arg1)
{
    if(arg1)
        ui->todayL->setVisible(true);
    else
        ui->todayL->setVisible(false);
}


void ToDoApp::on_action_About_triggered()
{
    QMessageBox::about(this, tr("About Application"),
             tr("The <b>Application</b> helps you to  manage your tasks"));
}


void ToDoApp::on_action_New_triggered()
{

    QMessageBox msgBox;
    msgBox.setText("Opening a new file.");
    msgBox.setInformativeText("Do you want to save this file before opening a new one?");
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No| QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Yes);
    int ret = msgBox.exec();
    switch (ret) {

      case QMessageBox::Yes:
        on_action_Save_triggered();

        todayModel->setStringList( QStringList{} );
        pendingModel->setStringList( QStringList{} );
        finishedModel->setStringList( QStringList{} );

         ui->todayL->setModel(todayModel);
         ui->pendingL->setModel(pendingModel);
         ui->finishedL->setModel(finishedModel);
          break;
      case QMessageBox::No:
        todayModel->setStringList( QStringList{} );
        pendingModel->setStringList( QStringList{} );
        finishedModel->setStringList( QStringList{} );
        ui->todayL->setModel(todayModel);
        ui->pendingL->setModel(pendingModel);
        ui->finishedL->setModel(finishedModel);
          break;
      case QMessageBox::Cancel:

          break;
      default:

          break;
    }
}



void ToDoApp::on_actionRemove_triggered()
{
    todayModel->removeRows(ui->todayL->currentIndex().row(),1);
    pendingModel->removeRows(ui->pendingL->currentIndex().row(),1);
    finishedModel->removeRows(ui->finishedL->currentIndex().row(),1);

}


void ToDoApp::on_todayL_doubleClicked(const QModelIndex &index)
{
    addTaskDialog dialog;
  auto task = todayList[index.row()];
  QStringList list = task.split(" ");
  auto i=0;
  QString des{""} ;
   while(list[i] != "Due:"){


        des +=" " + list[i];
        i++;
   }

   qDebug()<<i;
   dialog.setDescription(des);
    dialog.setDate(list[i+1]);
    dialog.setTag(list[i+3]);


    auto reply=dialog.exec();
    if (reply==addTaskDialog::Accepted)
    {
        if (dialog.get_if_is_a_FinishedTask())
        {

         finishedList.push_back(dialog.getTask());

           finishedModel->setStringList(finishedList);
           ui->finishedL->setModel(finishedModel);

        }
     else if (QDate::currentDate() == dialog.getDate())
       {
            todayList.push_back(dialog.getTask());

              todayModel->setStringList(todayList);
              ui->todayL->setModel(todayModel);
        }
     else{
            pendingList.push_back(dialog.getTask());

              pendingModel->setStringList(pendingList);
              ui->pendingL->setModel(pendingModel);

}
    }
    todayList.removeAt(index.row());
    todayModel->setStringList(todayList);
    ui->todayL->setModel(todayModel);

}


void ToDoApp::on_pendingL_doubleClicked(const QModelIndex &index)
{

    addTaskDialog dialog;
  auto task = pendingList[index.row()];
  QStringList list = task.split(" ");
  auto i=0;
  QString des{""} ;
   while(list[i] != "Due:"){


        des +=" " + list[i];
        i++;
   }

   qDebug()<<i;
   dialog.setDescription(des);
    dialog.setDate(list[i+1]);
    dialog.setTag(list[i+3]);
    auto reply=dialog.exec();
    if (reply==addTaskDialog::Accepted)
    {
        if (dialog.get_if_is_a_FinishedTask())
        {

         finishedList.push_back(dialog.getTask());

           finishedModel->setStringList(finishedList);
           ui->finishedL->setModel(finishedModel);

        }
     else if (QDate::currentDate() == dialog.getDate())
       {
            todayList.push_back(dialog.getTask());

              todayModel->setStringList(todayList);
              ui->todayL->setModel(todayModel);
        }
     else{
            pendingList.push_back(dialog.getTask());

              pendingModel->setStringList(pendingList);
              ui->pendingL->setModel(pendingModel);

}
    }
    pendingList.removeAt(index.row());
    pendingModel->setStringList(pendingList);
    ui->pendingL->setModel(pendingModel);
}


void ToDoApp::on_finishedL_doubleClicked(const QModelIndex &index)
{
    addTaskDialog dialog;
  auto task = finishedList[index.row()];
  QStringList list = task.split(" ");
  auto i=0;
  QString des{""} ;
   while(list[i] != "Due:"){


        des +=" " + list[i];
        i++;
   }

   qDebug()<<i;
   dialog.setDescription(des);
    dialog.setDate(list[i+1]);
    dialog.setTag(list[i+3]);
    dialog.setFinished(true);
    auto reply=dialog.exec();
    if (reply==addTaskDialog::Accepted)
    {
        if (dialog.get_if_is_a_FinishedTask())
        {

         finishedList.push_back(dialog.getTask());

           finishedModel->setStringList(finishedList);
           ui->finishedL->setModel(finishedModel);

        }
     else if (QDate::currentDate() == dialog.getDate())
       {
            todayList.push_back(dialog.getTask());

              todayModel->setStringList(todayList);
              ui->todayL->setModel(todayModel);
        }
     else{
            pendingList.push_back(dialog.getTask());

              pendingModel->setStringList(pendingList);
              ui->pendingL->setModel(pendingModel);

}
    }
    finishedList.removeAt(index.row());
    finishedModel->setStringList(finishedList);
    ui->finishedL->setModel(finishedModel);
}
